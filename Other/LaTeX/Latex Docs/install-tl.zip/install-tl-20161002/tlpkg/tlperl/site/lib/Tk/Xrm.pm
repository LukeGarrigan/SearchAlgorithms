package Tk::Xrm;

use vars qw($VERSION);
$VERSION = '4.005'; # $Id: //depot/Tkutf8/Tk/Xrm.pm#4 $

use Tk ();
1;
__END__

